//header file for all basic test functions
int print_pass_fail(int);
int set_diff_value_types();
int normal_ops();
int break_things();
int test_range_case();